# Movie_Recommendation
This project is a movie recommendation system based on popularity. It recommends movies to users based on their popularity among all users.
The Popularity-based Movie Recommendation system works by identifying the most popular movies based on their ratings and recommending them to users. The popularity of a movie is determined by the number of ratings it has received from users.

The project utilizes a dataset that contains movie ratings provided by users. Each rating consists of the movie ID, user ID, and the rating value. The project focuses on analyzing the popularity of movies and generating recommendations based on their popularity.

•	Project Weblink: https://movie-recommendation-system-1950-2016.onrender.com/?
